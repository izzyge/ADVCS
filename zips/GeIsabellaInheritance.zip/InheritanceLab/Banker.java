public class Banker extends Company{
  public Banker(String name, String photoFile, String companyName){
    super(name, photoFile, "Banker",companyName);
  }
}
