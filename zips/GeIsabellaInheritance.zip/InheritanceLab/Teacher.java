public class Teacher extends Government{
  public Teacher(String name, String photoFile, String cityName){
    super(name, photoFile, "Teacher",cityName);
  }
}
