public class Engineer extends Company{
  public Engineer(String name, String photoFile, String companyName){
    super(name, photoFile, "Engineer",companyName);
  }
}
