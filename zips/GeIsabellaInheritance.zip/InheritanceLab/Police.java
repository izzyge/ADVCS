public class Police extends Government{
  public Police(String name, String photoFile, String cityName){
    super(name, photoFile, "Police",cityName);
  }
}
